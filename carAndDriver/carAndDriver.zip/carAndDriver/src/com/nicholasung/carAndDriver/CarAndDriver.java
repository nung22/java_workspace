package com.nicholasung.carAndDriver;

public class CarAndDriver {

	public static void main(String[] args) {
		Driver driver1 = new Driver();
		driver1.drive();
		driver1.drive();
		driver1.drive();
		driver1.drive();
		driver1.useBoosters();
		driver1.refuel();
		driver1.refuel();
		driver1.refuel();
		driver1.refuel();
		driver1.useBoosters();
		driver1.useBoosters();
		driver1.drive();
		driver1.useBoosters();
		driver1.drive();
		driver1.drive();
	}

}
